# ── TEST DATA ────────────────────────────
TEST_TICKERS                = ["005930"]
TEST_START_DATE             = "20250101"
TEST_END_DATE               = "20251231"
TEST_CAPITAL                = 10_000_000.0
TEST_DAYS                   = 10
LOOKBACK_MINUTES            = 120
FORCE_CLOSE_MINUTES_BEFORE  = 15
FORCE_REFRESH               = False         # 데이터 강제로 다시 읽어올도록 설정

COMMISSION_RATE             = 0.00015       # 증권사 수수료(편도 0.015%)
TAX_RATE                    = 0.0018        # 코스피 매도 세율 (0.18%)
SLIPPAGE_RATE               = 0.001         # 슬리피지 (보수적으로 0.1%)

RSI_OVERSOLD                = 35.0          # RSI 과매도 임계값 (이 이하 → BUY 후보)
RSI_OVERBOUGHT              = 65.0          # RSI 과매수 임계값 (이 이상 → SELL 후보)
RSI_CLOSEOVER_BASE          = 0.3           # 크로스오버 자체의 베이스 신뢰도

# 결합 정보
NUMERIC_COMBINED_WEIGHT     = 0.5
PATTERN_COMBINED_WEIGHT     = 0.5

# 필터 값
MAX_LATENCY_MS              = 5000.0        # 최대 시간 지연 값
MIN_COMBINED_SCORE          = 0.55          # 최소 임계값

# 투자 건당 최대 금액 비율
MAX_POSITION_PCT            = 0.1           # 10%

# Triple Barrier 라벨링 임계값
TAKE_PROFIT                 = 0.005         # +0.5%
STOP_LOSS                   = 0.003         # -0.3%
TIME_HORIZON                = 60            # 60분

# ── SYSTEM ──────────────────────────────
# common
SEED                        = 42
ZERO                        = 1e-8

# directory
DATA_DIR                    = "data"
STORE_DIR                   = "store"
STORE_FNAME                 = "minute_bars.parquet"
LOG_DIR                     = "logs"
SNAPSHOTS_DIR               = "snapshots"

# date & time
CURR_TIMEZONE               = "Asia/Seoul"
DATE_FORMAT                 = "%Y%m%d"

# KIS API Config
VAR_KIS_APP_KEY             = "KIS_APP_KEY"
VAR_KIS_APP_SECRET          = "KIS_APP_SECRET"
VAR_KIS_ACCOUNT_NO          = "KIS_ACCOUNT_NO"
VAR_KIS_MOCK                = "KIS_MOCK"

# 데이터 출처
LOAD_STORE                  = "STORE"
LOAD_KIS                    = "KIS"
LOAD_PYKRX                  = "PYKRX"

# ── MARKET INFO ────────────────────────────
MARKET_OPEN_TIME            = "09:00"
MARKET_CLOSE_TIME           = "15:30"
MARKET_DAYS_PER_YEAR        = 252 
MINUTES_PER_DAY             = 60 * 6 + 30   # 09:00 ~ 15:30 = 390분
